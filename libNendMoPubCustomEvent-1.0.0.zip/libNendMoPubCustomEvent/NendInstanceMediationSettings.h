//
//  NendInstanceMediationSettings.h
//  MoPubCustomEventAdapter
//
//  Copyright © 2017年 F@N Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#else
    #import "MPMediationSettingsProtocol.h"
#endif

@interface NendInstanceMediationSettings : NSObject <MPMediationSettingsProtocol>

@property (nonatomic, copy) NSString *userId;

@end
