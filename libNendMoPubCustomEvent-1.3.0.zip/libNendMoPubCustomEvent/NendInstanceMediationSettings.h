//
//  NendInstanceMediationSettings.h
//  MoPubCustomEventAdapter
//
//  Copyright © 2017年 F@N Communications, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#if __has_include(<MoPub/MoPub.h>)
    #import <MoPub/MoPub.h>
#elif __has_include(<MoPubSDKFramework/MoPub.h>)
    #import <MoPubSDKFramework/MoPub.h>
#else
    #import "MPMediationSettingsProtocol.h"
#endif

typedef NS_ENUM(NSInteger, NendMediatoinGender) {
    NendAdGenderMale = 1,
    NendAdGenderFemale = 2
};

@interface NendInstanceMediationSettings : NSObject <MPMediationSettingsProtocol>

@property (nonatomic, copy) NSString *userId;

- (void)setAge:(NSInteger)age;
- (void)setGender:(NendMediatoinGender)gender;
- (void)setBirthdayWithYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day;
- (void)addCustomIntegerValue:(NSInteger)value forKey:(NSString *)key;
- (void)addCustomDoubleValue:(double)value forKey:(NSString *)key;
- (void)addCustomBoolValue:(BOOL)value forKey:(NSString *)key;
- (void)addCustomStringValue:(NSString *)value forKey:(NSString *)key;
@end
